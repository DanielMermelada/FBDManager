package com.usabana.finalproject.DataAccessObject.Controller;

import com.usabana.finalproject.DataAccessObject.DAOException;
import com.usabana.finalproject.DataAccessObject.DBDAO.cityDAO;
import com.usabana.finalproject.DataAccessObject.DBDAO.countryDAO;
import com.usabana.finalproject.DataAccessObject.DBDAO.countrylanguageDAO;
import com.usabana.finalproject.DataAccessObject.MySQLDAO.MySQLcityDAO;
import com.usabana.finalproject.DataAccessObject.MySQLDAO.MySQLcountryDAO;
import com.usabana.finalproject.DataAccessObject.MySQLDAO.MySQLcountrylanguageDAO;
import com.usabana.finalproject.DatabaseModel.country;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class MySQLDAOController implements DAOController{

    private Connection Connect;
    private cityDAO City = null;
    private countryDAO Country = null;
    private countrylanguageDAO CountryLanguage = null;

    public MySQLDAOController(String Host, String Database, String User, String Password) throws SQLException {
        Connect = DriverManager.getConnection("jdbc:mysql://"+Host+"/"+Database , User, Password);
    }

    public cityDAO getcityDAO() {
        if (City == null){
            City = new MySQLcityDAO(Connect);
        }
        return City;
    }

    public countryDAO getcountryDAO() {
        if (Country == null){
            Country = new MySQLcountryDAO(Connect);
        }
        return Country;
    }

    public countrylanguageDAO getcountrylanguageDAO() {
        if (CountryLanguage == null){
            CountryLanguage = new MySQLcountrylanguageDAO(Connect);
        }
        return CountryLanguage;
    }

}
