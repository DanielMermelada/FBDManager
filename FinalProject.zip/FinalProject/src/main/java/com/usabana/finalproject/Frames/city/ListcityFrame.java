package com.usabana.finalproject.Frames.city;

import com.usabana.finalproject.DataAccessObject.Controller.DAOController;
import com.usabana.finalproject.DataAccessObject.Controller.MySQLDAOController;
import com.usabana.finalproject.DataAccessObject.DAOException;
import com.usabana.finalproject.DatabaseModel.city;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ListcityFrame extends javax.swing.JFrame {
    
    private DAOController Controller;
    
    private cityTableModel Model;
    
    private Connection Connect;
    
    final String GET = "SELECT ID FROM city WHERE ID = ?";

    public ListcityFrame(DAOController Controller) throws DAOException {
        initComponents();
        this.Controller = Controller;
        this.Model = new cityTableModel(Controller.getcityDAO());
        this.Model.UpdateModel();
        this.Table.setModel(Model);
        this.Table.getSelectionModel().addListSelectionListener(e -> {
            boolean ValidSelection = (Table.getSelectedRow() != -1);
            EditButton.setEnabled(ValidSelection);
            DeleteButton.setEnabled(ValidSelection);
        });
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Toolbar = new javax.swing.JToolBar();
        NewButton = new javax.swing.JButton();
        Separator = new javax.swing.JToolBar.Separator();
        EditButton = new javax.swing.JButton();
        DeleteButton = new javax.swing.JButton();
        Separator2 = new javax.swing.JToolBar.Separator();
        SaveButton = new javax.swing.JButton();
        CancelButton = new javax.swing.JButton();
        Progress = new javax.swing.JLabel();
        Panel = new javax.swing.JPanel();
        ScrollPaneTable = new javax.swing.JScrollPane();
        Table = new javax.swing.JTable();
        citypaneldata = new com.usabana.finalproject.Frames.city.cityPanelData();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Gestor City");

        Toolbar.setRollover(true);

        NewButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/add_user.png"))); // NOI18N
        NewButton.setText("Nuevo");
        NewButton.setBorderPainted(false);
        NewButton.setContentAreaFilled(false);
        NewButton.setFocusable(false);
        NewButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        NewButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        NewButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NewButtonActionPerformed(evt);
            }
        });
        Toolbar.add(NewButton);
        Toolbar.add(Separator);

        EditButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/agt_family.png"))); // NOI18N
        EditButton.setText("Editar");
        EditButton.setBorderPainted(false);
        EditButton.setContentAreaFilled(false);
        EditButton.setEnabled(false);
        EditButton.setFocusable(false);
        EditButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EditButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        EditButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditButtonActionPerformed(evt);
            }
        });
        Toolbar.add(EditButton);

        DeleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/revert.png"))); // NOI18N
        DeleteButton.setText("Borrar");
        DeleteButton.setBorderPainted(false);
        DeleteButton.setContentAreaFilled(false);
        DeleteButton.setEnabled(false);
        DeleteButton.setFocusable(false);
        DeleteButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        DeleteButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Toolbar.add(DeleteButton);
        Toolbar.add(Separator2);

        SaveButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/save_all.png"))); // NOI18N
        SaveButton.setText("Guardar");
        SaveButton.setBorderPainted(false);
        SaveButton.setContentAreaFilled(false);
        SaveButton.setEnabled(false);
        SaveButton.setFocusable(false);
        SaveButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        SaveButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        SaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveButtonActionPerformed(evt);
            }
        });
        Toolbar.add(SaveButton);

        CancelButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/button_cancel.png"))); // NOI18N
        CancelButton.setText("Cancelar");
        CancelButton.setBorderPainted(false);
        CancelButton.setContentAreaFilled(false);
        CancelButton.setEnabled(false);
        CancelButton.setFocusable(false);
        CancelButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        CancelButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        CancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelButtonActionPerformed(evt);
            }
        });
        Toolbar.add(CancelButton);

        getContentPane().add(Toolbar, java.awt.BorderLayout.PAGE_START);

        Progress.setFont(Progress.getFont().deriveFont(Progress.getFont().getSize()-2f));
        Progress.setText("To Change");
        Progress.setBorder(javax.swing.BorderFactory.createEmptyBorder(3, 3, 3, 3));
        getContentPane().add(Progress, java.awt.BorderLayout.PAGE_END);

        Panel.setLayout(new java.awt.BorderLayout());

        Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        ScrollPaneTable.setViewportView(Table);

        Panel.add(ScrollPaneTable, java.awt.BorderLayout.CENTER);
        Panel.add(citypaneldata, java.awt.BorderLayout.LINE_END);

        getContentPane().add(Panel, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private city getSelectedCity()throws DAOException{
        Integer IDTextField = (Integer) Table.getValueAt(Table.getSelectedRow(), 0);
        return Controller.getcityDAO().Get(IDTextField);
    }
            
    private void SaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveButtonActionPerformed
      
        PreparedStatement Stat = null;
        ResultSet RS = null;
        
        
        try {
            
            citypaneldata.SaveData();
            city var = citypaneldata.getCity();
            
            Connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/world", "root", "0000257373");
            
            Stat = Connect.prepareStatement(GET);
            Stat.setInt(1, var.getID());
            RS = Stat.executeQuery();
            
            if (RS.next()){
                Controller.getcityDAO().Modify(var);
            }
            else {
                Controller.getcityDAO().Insert(var);
            }
           
        } catch (ParseException ex) {
            Logger.getLogger(ListcityFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DAOException ex) {
            Logger.getLogger(ListcityFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ListcityFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        finally {
            try {
                RS.close();
                Stat.close();
            } catch (SQLException ex) {
                new DAOException("Error en MySQL", ex);
            }
        }
    }//GEN-LAST:event_SaveButtonActionPerformed

    private void EditButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditButtonActionPerformed
        try {
            city City = getSelectedCity();
            citypaneldata.setCity(City);
            citypaneldata.setEditable(true);
            citypaneldata.LoadData();
            SaveButton.setEnabled(true);
            CancelButton.setEnabled(true);
        } catch (DAOException ex) {
            Logger.getLogger(ListcityFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_EditButtonActionPerformed

    private void NewButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NewButtonActionPerformed
        citypaneldata.setCity(null);
        citypaneldata.LoadData();
        citypaneldata.setEditable(true);
        SaveButton.setEnabled(true);
        CancelButton.setEnabled(true);
    }//GEN-LAST:event_NewButtonActionPerformed

    private void CancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelButtonActionPerformed
        citypaneldata.setCity(null);
        citypaneldata.setEditable(false);
        citypaneldata.LoadData();
        Table.clearSelection();
        SaveButton.setEnabled(false);
        CancelButton.setEnabled(false);
    }//GEN-LAST:event_CancelButtonActionPerformed

    public static void main(String args[]) throws SQLException {
        
        DAOController Controller = new MySQLDAOController("localhost:3306", "world", "root", "0000257373");
        
        java.awt.EventQueue.invokeLater(() -> {
            try {
                new ListcityFrame(Controller).setVisible(true);
            } catch (DAOException ex) {
                Logger.getLogger(ListcityFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CancelButton;
    private javax.swing.JButton DeleteButton;
    private javax.swing.JButton EditButton;
    private javax.swing.JButton NewButton;
    private javax.swing.JPanel Panel;
    private javax.swing.JLabel Progress;
    private javax.swing.JButton SaveButton;
    private javax.swing.JScrollPane ScrollPaneTable;
    private javax.swing.JToolBar.Separator Separator;
    private javax.swing.JToolBar.Separator Separator2;
    private javax.swing.JTable Table;
    private javax.swing.JToolBar Toolbar;
    private com.usabana.finalproject.Frames.city.cityPanelData citypaneldata;
    // End of variables declaration//GEN-END:variables
}
