package com.usabana.finalproject.DataAccessObject.DBDAO;

import com.usabana.finalproject.DataAccessObject.DAO;
import com.usabana.finalproject.DatabaseModel.city;

public interface cityDAO extends DAO<city, Integer> {

}
