package com.usabana.finalproject.DataAccessObject.MySQLDAO;

import com.usabana.finalproject.DataAccessObject.DAOException;
import com.usabana.finalproject.DataAccessObject.DBDAO.cityDAO;
import com.usabana.finalproject.DatabaseModel.city;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MySQLcityDAO implements cityDAO {

    private Connection Connect;

    final String INSERT = "INSERT INTO city(ID, Name, CountryCode, District, Population) VALUES(?, ?, ?, ?, ?)";
    final String UPDATE = "UPDATE city SET ID = ?, Name = ?, CountryCode = ?, District = ?, Population = ? WHERE ID = ?";
    final String DELETE = "DELETE FROM city WHERE ID = ?";
    final String GETALL= "SELECT ID, Name, CountryCode, District, Population FROM city";
    final String GET = "SELECT ID, Name, CountryCode, District, Population FROM city WHERE ID = ?";

    public MySQLcityDAO(Connection Connect){
        this.Connect = Connect;
    }

    public void Insert(city var) throws DAOException{

        PreparedStatement Stat = null;

        try {
            Stat = Connect.prepareStatement(INSERT);

            Stat.setInt(1, var.getID());
            Stat.setString(2, var.getName());
            Stat.setString(3, var.getCountryCode());
            Stat.setString(4, var.getDistrict());
            Stat.setInt(5, var.getPopulation());

            if (Stat.executeUpdate()==0){
                throw new DAOException("Puede que no se haya guardado");
            }
        }
        catch (SQLException ex) {
            throw new DAOException("Error en SQL", ex);
        }
        finally {
            if(Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException ex){
                    throw new DAOException("Error en SQL", ex);
                }
            }
        }
    }

    public void Modify(city var) throws DAOException{

        PreparedStatement Stat = null;

        try {
            Stat = Connect.prepareStatement(UPDATE);

            Stat.setInt(1, var.getID());
            Stat.setString(2, var.getName());
            Stat.setString(3, var.getCountryCode());
            Stat.setString(4, var.getDistrict());
            Stat.setInt(5, var.getPopulation());
            Stat.setInt(6, var.getID());
            
            if (Stat.executeUpdate()==0){
                throw new DAOException("Puede que no se haya guardado");
            }
        }
        catch (SQLException ex){
            throw new DAOException("Error en SQL", ex);
        }
        finally {
            if(Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException ex){
                    throw new DAOException("Error en SQL", ex);
                }
            }
        }
    }

    public void Delete(city var) throws DAOException{

        PreparedStatement Stat = null;

        try {
            Stat = Connect.prepareStatement(DELETE);

            Stat.setInt(1, var.getID());

            if (Stat.executeUpdate()==0){
                throw new DAOException("Puede que no se haya guardado");
            }
        }
        catch (SQLException ex) {
            throw new DAOException("Error en SQL", ex);
        }
        finally {
            if(Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException ex){
                    throw new DAOException("Error en SQL", ex);
                }
            }
        }
    }

    public List<city> GetAll() throws DAOException{

        PreparedStatement Stat = null;
        ResultSet RS = null;
        List<city> list = new ArrayList<>();

        try {
            Stat = Connect.prepareStatement(GETALL);

            RS = Stat.executeQuery();

            while (RS.next()){
                list.add(Convert(RS));
            }
        }
        catch (SQLException ex){
            throw new DAOException("Error en SQL.", ex);
        }
        finally {
            if (RS != null){
                try {
                    RS.close();
                }
                catch (SQLException ex){
                    new DAOException("Error en SQL", ex);
                }
            }
            if (Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException ex){
                    new DAOException("Error en SQL", ex);
                }
            }
        }
        return list;
    }

    public city Get(Integer pk) throws DAOException{

        PreparedStatement Stat = null;
        ResultSet RS = null;
        city field = null;

        try {
            Stat = Connect.prepareStatement(GET);

            Stat.setInt(1, pk);

            RS = Stat.executeQuery();

            if (RS.next()){
                field = Convert(RS);
            } else {
                throw new DAOException("No se ha encontrado este registro.");
            }
        }
        catch (SQLException ex){
            throw new DAOException("Error en SQL.", ex);
        }
        finally {
            if (RS != null){
                try {
                    RS.close();
                }
                catch (SQLException ex){
                    new DAOException("Error en SQL", ex);
                }
            }
            if (Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException ex){
                    new DAOException("Error en SQL", ex);
                }
            }
        }
        return field;
    }

    private city Convert(ResultSet RS) throws SQLException{
        int ID = RS.getInt("ID");
        String Name = RS.getString("Name");
        String CountryCode = RS.getString("CountryCode");
        String District = RS.getString("District");
        int Population = RS.getInt("Population");

        city City = new city(ID, Name, CountryCode, District, Population);

        return City;
    }
    
}