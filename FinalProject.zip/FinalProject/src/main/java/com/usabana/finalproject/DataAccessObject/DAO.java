package com.usabana.finalproject.DataAccessObject;

import java.util.List;

public interface DAO<Class, Type> {
    void Insert(Class var) throws DAOException;
    void Modify(Class var) throws DAOException;
    void Delete(Class var) throws DAOException;
    List<Class> GetAll() throws DAOException;
    Class Get(Type pk) throws DAOException;
}