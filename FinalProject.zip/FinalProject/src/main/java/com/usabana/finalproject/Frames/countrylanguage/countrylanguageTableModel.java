package com.usabana.finalproject.Frames.countrylanguage;

import com.usabana.finalproject.DataAccessObject.DAOException;
import com.usabana.finalproject.DataAccessObject.DBDAO.countrylanguageDAO;
import com.usabana.finalproject.DatabaseModel.countrylanguage;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class countrylanguageTableModel extends AbstractTableModel{
    
    private countrylanguageDAO CountryLanguage;
    
    private List<countrylanguage> Data = new ArrayList<>();
    
    public countrylanguageTableModel(countrylanguageDAO CountryLanguage){
        this.CountryLanguage = CountryLanguage;
    }
    
    public void UpdateModel()throws DAOException{
        Data = CountryLanguage.GetAll();
    }
    
    public String getColumnName(int column) {
        switch(column){
            case 0: return "CountryCode";
            case 1: return "Language";
            case 2: return "IsOfficial";
            case 3: return "Percentage";
            default: return null;
        }
    }

    public int getRowCount() {
       return Data.size();
    }

    public int getColumnCount() {
        return 4;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        countrylanguage Instance = Data.get(rowIndex);
        switch(columnIndex){
            case 0: return Instance.getCountryCode();
            case 1: return Instance.getLanguage();
            case 2: return Instance.getIsOfficial();
            case 3: return Instance.getPercentage();
            default: return null;
        }
    }
    
}
