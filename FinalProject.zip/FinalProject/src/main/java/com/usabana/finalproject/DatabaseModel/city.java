package com.usabana.finalproject.DatabaseModel;

public class city {
   
    private int ID;
    private String Name;
    private String CountryCode;
    private String District;
    private int Population;

    public city(int ID, String Name, String CountryCode, String District, int Population) {
        this.ID = ID;
        this.Name = Name;
        this.CountryCode = CountryCode;
        this.District = District;
        this.Population = Population;
    }

    public city() {
        //VER VALORES NULL EN INTS//
        this.ID = 0;
        this.Name = "";
        this.CountryCode = "";
        this.District = "";
        this.Population = 0;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getCountryCode() {
        return CountryCode;
    }

    public void setCountryCode(String countryCode) {
        this.CountryCode = countryCode;
    }

    public String getDistrict() {
        return District;
    }

    public void setDistrict(String district) {
        this.District = district;
    }

    public int getPopulation() {
        return Population;
    }

    public void setPopulation(int population) {
        this.Population = population;
    }

    public String toString() {
        return "city{" +
                "ID=" + ID +
                ", Name='" + Name + '\'' +
                ", CountryCode='" + CountryCode + '\'' +
                ", District='" + District + '\'' +
                ", Population=" + Population +
                '}';
    }
}