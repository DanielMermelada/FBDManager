package Integration;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

public class Graphics extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    //Propiedades Visuales - Las propiedades utilizadas como botones, declaradas para aparecer en la interfaz
    private Scene scene;

    private Button addCampo;
    private Button deleteCampo;
    private Button buscarCampo;

    //Para el menú - Derivada de las propiedades para el menu desplegable
    private MenuBar menuBar;
    private Map<String, MenuItem> fileMenuItems;
    private TextField columnasInput;
    private TextField columnaInput;
    private TextField tablaInput;

    @Override
    public void start(Stage primaryStage) {



    }
    private void setUp() {

        HBox hBox = new HBox();
        hBox.setPadding(new Insets(10, 10, 10, 10));
        hBox.setSpacing(10);
        hBox.getChildren().addAll(columnasInput, columnaInput, tablaInput, addCampo, buscarCampo, deleteCampo);

        //Border Pane - Para el menu de importar y exportar
        BorderPane borderPane = new BorderPane();
        borderPane.setTop(menuBar);
        menuBar.setStyle("-fx-background-color: NAVAJOWHITE");
        borderPane.setMaxWidth(75);

        //Layout - Se crea para la escena
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20, 20, 20, 20));
        layout.getChildren().addAll(borderPane, hBox);


        //Scene - Se crea como punto de partida para la vista
        layout.setStyle("-fx-background-color: LIGHTSLATEGRAY;");
        scene = new Scene(layout, 900, 550);
    }
    private void setUpCrud() {
        addCampo = new Button();
        addCampo.setStyle("-fx-background-color: Orange");
        addCampo.setText("¡Adiciona!");
        addCampo.setMinWidth(70);

        buscarCampo = new Button();
        buscarCampo.setStyle("-fx-background-color: Orange");
        buscarCampo.setText("¡Busca!");
        buscarCampo.setMinWidth(70);

        deleteCampo = new Button();
        deleteCampo.setStyle("-fx-background-color: Orange");
        deleteCampo.setText("¡Elimina!");
        deleteCampo.setMinWidth(70);

    }
    private void setupInputs(){

        columnasInput = new TextField();
        columnasInput.setStyle("-fx-background-color: NAVAJOWHITE");
        columnasInput.setPromptText("Datos");
        columnasInput.setMinWidth(30);

        columnaInput = new TextField();
        columnaInput.setStyle("-fx-background-color: NAVAJOWHITE");
        columnaInput.setPromptText("Dato");
        columnaInput.setMinWidth(30);

        tablaInput = new TextField();
        tablaInput.setStyle("-fx-background-color: NAVAJOWHITE");
        tablaInput.setPromptText("Tabla");
        tablaInput.setMinWidth(30);
    }
    //setupMenu - Este es el encargado de dar las propiedades a nuestra barra de import/export
    private void setupMenu() {
        Menu fileMenu = new Menu("Archivo");

        fileMenuItems = new HashMap<>();
        fileMenuItems.put("Import", new MenuItem("Import"));
        fileMenuItems.put("Export", new MenuItem("Export"));

        fileMenu.getItems().add(fileMenuItems.get("Import"));
        fileMenu.getItems().add(fileMenuItems.get("Export"));

        menuBar = new MenuBar();
        menuBar.getMenus().add(fileMenu);
    }

}
