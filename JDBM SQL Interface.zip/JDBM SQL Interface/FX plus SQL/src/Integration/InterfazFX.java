package Integration;

public class InterfazFX {
}
