package Integration;
import java.sql.*;



public class Main_Interface {
    public static void main(String[] x) {new Main_Interface(); }
    public Main_Interface() {this.connector();}
    private void connector(){

        String url = "jdbc:mysql://localhost:3306/world";
        String user = "root";
        String password = "TitwIatsOtsdiaYbtvtystd*66";
        String Signs_of_life = "Wut";
        Connection conn;
        try {
            // The newInstance() call is a work around for some
            // broken Java implementations

            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection(url, user, password);
            Statement stmt = null;
            ResultSet rs = null;

            try {
                stmt = conn.createStatement();
                rs = stmt.executeQuery("SELECT name,code FROM country WHERE name like 'E%' limit 10");

                // or alternatively, if you don't know ahead of time that
                // the query will be a SELECT...

                if (stmt.execute("SELECT name,code FROM country WHERE name like 'E%' limit 10")) {
                    rs = stmt.getResultSet();
                }

                // Now do something with the ResultSet ....
                while (rs.next()) {
                    System.out.println(rs.getString("name") + "\t"+
                                        rs.getString("code"));

                }
            }
            catch (SQLException ex){
                // handle any errors
                System.out.println("SQLException: " + ex.getMessage());
                System.out.println("SQLState: " + ex.getSQLState());
                System.out.println("VendorError: " + ex.getErrorCode());
            }
            finally {
                // it is a good idea to release
                // resources in a finally{} block
                // in reverse-order of their creation
                // if they are no-longer needed

                if (rs != null) {
                    try {
                        rs.close();
                    } catch (SQLException sqlEx) { } // ignore

                    rs = null;
                }

                if (stmt != null) {
                    try {
                        stmt.close();
                    } catch (SQLException sqlEx) { } // ignore

                    stmt = null;
                }
            }
        } catch (SQLException | ClassNotFoundException ex) {
            // handle the error
            System.out.println(ex.getMessage());
        } catch (InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    }
