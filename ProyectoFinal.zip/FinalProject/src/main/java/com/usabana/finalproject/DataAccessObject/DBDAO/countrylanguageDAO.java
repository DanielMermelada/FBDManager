package com.usabana.finalproject.DataAccessObject.DBDAO;

import com.usabana.finalproject.DataAccessObject.DAOException;
import com.usabana.finalproject.DatabaseModel.countrylanguage;

import java.util.List;

public interface countrylanguageDAO {
    void Insert(countrylanguage var) throws DAOException;
    void Modify(countrylanguage var) throws DAOException;
    void Delete(countrylanguage var) throws DAOException;
    List<countrylanguage> GetAll() throws DAOException;
    countrylanguage Get(String Language, String CountryCode) throws DAOException;
}