package com.usabana.finalproject.DataAccessObject.MySQLDAO;

import com.usabana.finalproject.DataAccessObject.DAOException;
import com.usabana.finalproject.DataAccessObject.DBDAO.countryDAO;
import com.usabana.finalproject.DatabaseModel.country;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MySQLcountryDAO implements countryDAO {

    private Connection Connect;

    final String INSERT = "INSERT INTO country(Code, Name, Continent, Region, SurfaceArea, IndepYear, Population, LifeExpectancy, GNP, GNPOld, LocalName, GovernmentForm, HeadOfState, Capital, Code2) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    final String UPDATE = "UPDATE country SET Code = ?, Name = ?, Continent = ?, Region = ?, SurfaceArea = ?, IndepYear = ?, Population = ?, LifeExpectancy = ?, GNP = ?, GNPOld = ?, LocalName = ?, GovernmentForm = ?, HeadOfState = ?, Capital = ?, Code2 = ? WHERE Code = ?";
    final String DELETE = "DELETE FROM country WHERE Code = ?";
    final String GETALL= "SELECT Code, Name, Continent, Region, SurfaceArea, IndepYear, Population, LifeExpectancy, GNP, GNPOld, LocalName, GovernmentForm, HeadOfState, Capital, Code2 from country";
    final String GET = "SELECT Code, Name, Continent, Region, SurfaceArea, IndepYear, Population, LifeExpectancy, GNP, GNPOld, LocalName, GovernmentForm, HeadOfState, Capital, Code2 from country WHERE Code = ?";

    public MySQLcountryDAO(Connection Connect){
        this.Connect = Connect;
    }

    public void Insert(country var) throws DAOException{

        PreparedStatement Stat = null;

        try {
            Stat = Connect.prepareStatement(INSERT);

            Stat.setString(1, var.getCode());
            Stat.setString(2, var.getName());
            Stat.setString(3, var.getContinent());
            Stat.setString(4, var.getRegion());
            Stat.setFloat(5, var.getSurfaceArea());
            Stat.setInt(6, var.getIndepYear());
            Stat.setInt(7, var.getPopulation());
            Stat.setFloat(8, var.getLifeExpectancy());
            Stat.setFloat(9, var.getGNP());
            Stat.setFloat(10, var.getGNPOld());
            Stat.setString(11, var.getLocalName());
            Stat.setString(12, var.getGovernmentForm());
            Stat.setString(13, var.getHeadOfState());
            Stat.setInt(14, var.getCapital());
            Stat.setString(15, var.getCode2());

            Stat.executeUpdate();

            if (Stat.executeUpdate()==0){
                throw new DAOException("Puede que no se haya guardado");
            }
        }
        catch (SQLException exception) {
            throw new DAOException("Error en SQL", exception);
        }
        finally {
            if(Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException exception){
                    throw new DAOException("Error en SQL", exception);
                }
            }
        }
    }

    public void Modify(country var) throws DAOException{

        PreparedStatement Stat = null;

        try {
            Stat = Connect.prepareStatement(UPDATE);

            Stat.setString(1, var.getCode());
            Stat.setString(2, var.getName());
            Stat.setString(3, var.getContinent());
            Stat.setString(4, var.getRegion());
            Stat.setFloat(5, var.getSurfaceArea());
            Stat.setInt(6, var.getIndepYear());
            Stat.setInt(7, var.getPopulation());
            Stat.setFloat(8, var.getLifeExpectancy());
            Stat.setFloat(9, var.getGNP());
            Stat.setFloat(10, var.getGNPOld());
            Stat.setString(11, var.getLocalName());
            Stat.setString(12, var.getGovernmentForm());
            Stat.setString(13, var.getHeadOfState());
            Stat.setInt(14, var.getCapital());
            Stat.setString(15, var.getCode2());
            Stat.setString(16, var.getCode());

            Stat.executeUpdate();

            if (Stat.executeUpdate()==0){
                throw new DAOException("Puede que no se haya guardado");
            }
        }
        catch (SQLException exception){
            throw new DAOException("Error en SQL", exception);
        }
        finally {
            if(Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException exception){
                    throw new DAOException("Error en SQL", exception);
                }
            }
        }
    }

    public void Delete(country var) throws DAOException{

        PreparedStatement Stat = null;

        try {
            Stat = Connect.prepareStatement(DELETE);

            Stat.setString(1, var.getCode());

            Stat.executeUpdate();

            if (Stat.executeUpdate()==0){
                throw new DAOException("Puede que no se haya guardado");
            }
        }
        catch (SQLException exception) {
            throw new DAOException("Error en SQL", exception);
        }
        finally {
            if(Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException exception){
                    throw new DAOException("Error en SQL", exception);
                }
            }
        }
    }

    public List<country> GetAll() throws DAOException{

        PreparedStatement Stat = null;
        ResultSet RS = null;
        List<country> list = new ArrayList<>();

        try {
            Stat = Connect.prepareStatement(GETALL);

            RS = Stat.executeQuery();

            while (RS.next()){
                list.add(Convert(RS));
            }
        }
        catch (SQLException exception){
            throw new DAOException("Error en SQL.", exception);
        }
        finally {
            if (RS != null){
                try {
                    RS.close();
                }
                catch (SQLException exception){
                    new DAOException("Error en SQL", exception);
                }
            }
            if (Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException exception){
                    new DAOException("Error en SQL", exception);
                }
            }
        }
        return list;
    }

    public country Get(String pk) throws DAOException{

        PreparedStatement Stat = null;
        ResultSet RS = null;
        country field = null;

        try {
            Stat = Connect.prepareStatement(GET);

            Stat.setString(1, pk);

            RS = Stat.executeQuery();

            if (RS.next()){
                field = Convert(RS);
            } else {
                throw new DAOException("No se ha encontrado ese registro.");
            }
        }
        catch (SQLException exception){
            throw new DAOException("Error en SQL.", exception);
        }
        finally {
            if (RS != null){
                try {
                    RS.close();
                }
                catch (SQLException exception){
                    new DAOException("Error en SQL", exception);
                }
            }
            if (Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException exception){
                    new DAOException("Error en SQL", exception);
                }
            }
        }
        return field;
    }

    private country Convert(ResultSet RS) throws SQLException{
        String Code = RS.getString("Code");
        String Name = RS.getString("Name");
        String Continent = RS.getString("Continent");
        String Region = RS.getString("Region");
        float SurfaceArea = RS.getFloat("SurfaceArea");
        int IndepYear = RS.getInt("IndepYear");
        int Population = RS.getInt("Population");
        float LifeExpectancy = RS.getFloat("LifeExpectancy");
        float GNP = RS.getFloat("GNP");
        float GNPOld = RS.getFloat("GNPOld");
        String LocalName = RS.getString("LocalName");
        String GovernmentForm = RS.getString("GovernmentForm");
        String HeadOfState = RS.getString("HeadOfState");
        int Capital = RS.getInt("Capital");
        String Code2 = RS.getString("Code2");

        country Country = new country(Code, Name, Continent, Region, SurfaceArea, IndepYear, Population, LifeExpectancy, GNP, GNPOld, LocalName, GovernmentForm, HeadOfState, Capital, Code2);

        return Country;
    }
}