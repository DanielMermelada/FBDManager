package com.usabana.finalproject.DataAccessObject.DBDAO;

import com.usabana.finalproject.DataAccessObject.DAO;
import com.usabana.finalproject.DatabaseModel.country;

public interface countryDAO extends DAO<country, String> {

}