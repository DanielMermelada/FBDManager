package com.usabana.finalproject.Frames.city;

import com.usabana.finalproject.DatabaseModel.city;
import java.text.ParseException;

public class cityPanelData extends javax.swing.JPanel {
    
    private city City;
    
    private boolean Editable;

    public cityPanelData() {
        initComponents();
    }

    public city getCity() {
        return City;
    }

    public void setCity(city City) {
        this.City = City;
    }

    public boolean isEditable() {
        return Editable;
    }

    public void setEditable(boolean Editable) {
        this.Editable = Editable;
        IDTextField.setEditable(Editable);
        NameTextField.setEditable(Editable);
        CountryCodeTextField.setEditable(Editable);
        DistrictTextField.setEditable(Editable);
        PopulationTextField.setEditable(Editable);
    }
    
    public void LoadData(){
        if (City != null){
            IDTextField.setValue(City.getID());
            NameTextField.setText(City.getName());
            CountryCodeTextField.setText(City.getCountryCode());
            DistrictTextField.setText(City.getDistrict());
            PopulationTextField.setValue(City.getPopulation());
        } else {
            IDTextField.setText("");
            NameTextField.setText("");
            CountryCodeTextField.setText("");
            DistrictTextField.setText("");
            PopulationTextField.setText("");
        }
        IDTextField.requestFocus();
    }
    
    public void SaveData()throws ParseException{
        if (City == null){
            City = new city();
        }
        IDTextField.commitEdit();
        City.setID((int)IDTextField.getValue());
        City.setName(NameTextField.getText());
        City.setCountryCode(CountryCodeTextField.getText());
        City.setDistrict(DistrictTextField.getText());
        PopulationTextField.commitEdit();
        City.setPopulation((int) PopulationTextField.getValue());
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        IDLabel = new javax.swing.JLabel();
        NameLabel = new javax.swing.JLabel();
        CountryCodeLabel = new javax.swing.JLabel();
        DistrictLabel = new javax.swing.JLabel();
        PopulationLabel = new javax.swing.JLabel();
        NameTextField = new javax.swing.JTextField();
        CountryCodeTextField = new javax.swing.JTextField();
        DistrictTextField = new javax.swing.JTextField();
        IDTextField = new javax.swing.JFormattedTextField();
        PopulationTextField = new javax.swing.JFormattedTextField();

        IDLabel.setText("ID:");

        NameLabel.setText("Name:");

        CountryCodeLabel.setText("CountryCode:");

        DistrictLabel.setText("District:");

        PopulationLabel.setText("Population:");

        NameTextField.setText("Name");

        CountryCodeTextField.setText("CountryCode");

        DistrictTextField.setText("District");

        IDTextField.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));
        IDTextField.setText("ID");

        PopulationTextField.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));
        PopulationTextField.setText("Population");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(IDLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(IDTextField))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(PopulationLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PopulationTextField))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(DistrictLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CountryCodeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(NameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(NameTextField)
                            .addComponent(DistrictTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 272, Short.MAX_VALUE)
                            .addComponent(CountryCodeTextField))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(IDLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(IDTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CountryCodeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CountryCodeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DistrictLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DistrictTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PopulationLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PopulationTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel CountryCodeLabel;
    private javax.swing.JTextField CountryCodeTextField;
    private javax.swing.JLabel DistrictLabel;
    private javax.swing.JTextField DistrictTextField;
    private javax.swing.JLabel IDLabel;
    private javax.swing.JFormattedTextField IDTextField;
    private javax.swing.JLabel NameLabel;
    private javax.swing.JTextField NameTextField;
    private javax.swing.JLabel PopulationLabel;
    private javax.swing.JFormattedTextField PopulationTextField;
    // End of variables declaration//GEN-END:variables
}
