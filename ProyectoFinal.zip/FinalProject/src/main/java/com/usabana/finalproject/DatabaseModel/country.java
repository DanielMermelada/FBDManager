package com.usabana.finalproject.DatabaseModel;

public class country {
   
    private String Code;
    private String Name;
    private String Continent;
    private String Region;
    private float SurfaceArea;
    private int IndepYear;
    private int Population;
    private float LifeExpectancy;
    private float GNP;
    private float GNPOld;
    private String LocalName;
    private String GovernmentForm;
    private String HeadOfState;
    private int Capital;
    private String Code2;

    public country(String code, String name, String continent, String region, float surfaceArea, int indepYear, int population, float lifeExpectancy, float gNP, float gNPOld, String localName, String governmentForm, String headOfState, int capital, String code2) {
        this.Code = code;
        this.Name = name;
        this.Continent = continent;
        this.Region = region;
        this.SurfaceArea = surfaceArea;
        this.IndepYear = indepYear;
        this.Population = population;
        this.LifeExpectancy = lifeExpectancy;
        this.GNP = gNP;
        this.GNPOld = gNPOld;
        this.LocalName = localName;
        this.GovernmentForm = governmentForm;
        this.HeadOfState = headOfState;
        this.Capital = capital;
        this.Code2 = code2;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String code) {
        this.Code = code;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getContinent() {
        return Continent;
    }

    public void setContinent(String continent) {
        this.Continent = continent;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String region) {
        this.Region = region;
    }

    public float getSurfaceArea() {
        return SurfaceArea;
    }

    public void setSurfaceArea(float surfaceArea) {
        this.SurfaceArea = surfaceArea;
    }

    public int getIndepYear() {
        return IndepYear;
    }

    public void setIndepYear(Integer indepYear) {
        this.IndepYear = indepYear;
    }

    public int getPopulation() {
        return Population;
    }

    public void setPopulation(int population) {
        this.Population = population;
    }

    public float getLifeExpectancy() {
        return LifeExpectancy;
    }

    public void setLifeExpectancy(Float lifeExpectancy) {
        this.LifeExpectancy = lifeExpectancy;
    }

    public float getGNP() {
        return GNP;
    }

    public void setGNP(float GNP) {
        this.GNP = GNP;
    }

    public float getGNPOld() {
        return GNPOld;
    }

    public void setGNPOld(Float GNPOld) {
        this.GNPOld = GNPOld;
    }

    public String getLocalName() {
        return LocalName;
    }

    public void setLocalName(String localName) {
        this.LocalName = localName;
    }

    public String getGovernmentForm() {
        return GovernmentForm;
    }

    public void setGovernmentForm(String governmentForm) {
        this.GovernmentForm = governmentForm;
    }

    public String getHeadOfState() {
        return HeadOfState;
    }

    public void setHeadOfState(String headOfState) {
        this.HeadOfState = headOfState;
    }

    public int getCapital() {
        return Capital;
    }

    public void setCapital(Integer capital) {
        this.Capital = capital;
    }

    public String getCode2() {
        return Code2;
    }

    public void setCode2(String code2) {
        this.Code2 = code2;
    }

    public String toString() {
        return "country{" +
                "Code='" + Code + '\'' +
                ", Name='" + Name + '\'' +
                ", Continent='" + Continent + '\'' +
                ", Region='" + Region + '\'' +
                ", SurfaceArea=" + SurfaceArea +
                ", IndepYear=" + IndepYear +
                ", Population=" + Population +
                ", LifeExpectancy=" + LifeExpectancy +
                ", GNP=" + GNP +
                ", GNPOld=" + GNPOld +
                ", LocalName='" + LocalName + '\'' +
                ", GovernmentForm='" + GovernmentForm + '\'' +
                ", HeadOfState='" + HeadOfState + '\'' +
                ", Capital=" + Capital +
                ", Code2='" + Code2 + '\'' +
                '}';
    } 
    
}
