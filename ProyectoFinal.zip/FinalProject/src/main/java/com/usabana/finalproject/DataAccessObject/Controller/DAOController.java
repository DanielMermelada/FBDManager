package com.usabana.finalproject.DataAccessObject.Controller;

import com.usabana.finalproject.DataAccessObject.DBDAO.cityDAO;
import com.usabana.finalproject.DataAccessObject.DBDAO.countryDAO;
import com.usabana.finalproject.DataAccessObject.DBDAO.countrylanguageDAO;

public interface DAOController {

    cityDAO getcityDAO();

    countryDAO getcountryDAO();

    countrylanguageDAO getcountrylanguageDAO();

}