package com.usabana.finalproject.Frames.countrylanguage;

import com.usabana.finalproject.DataAccessObject.Controller.DAOController;
import com.usabana.finalproject.DataAccessObject.DAOException;

public class ListcountrylanguageFrame extends javax.swing.JFrame {
    
    private DAOController Controller;
    
    private countrylanguageTableModel Model;

    public ListcountrylanguageFrame(DAOController Controller) throws DAOException {
        initComponents();
        this.Controller = Controller;
        this.Model = new countrylanguageTableModel();
        this.Table.setModel(Model);
        UpdateTable();
    }
    
    void UpdateTable()throws DAOException {
        Progress.setText("Actualizando datos...");
        Model.UpdateModel();
        Model.fireTableDataChanged();
        Progress.setText(Model.getRowCount()+" registros visibles.");
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Toolbar = new javax.swing.JToolBar();
        NewButton = new javax.swing.JButton();
        Separator = new javax.swing.JToolBar.Separator();
        EditButton = new javax.swing.JButton();
        DeleteButton = new javax.swing.JButton();
        Separator2 = new javax.swing.JToolBar.Separator();
        SaveButton = new javax.swing.JButton();
        CancelButton = new javax.swing.JButton();
        Progress = new javax.swing.JLabel();
        Panel = new javax.swing.JPanel();
        ScrollPaneTable = new javax.swing.JScrollPane();
        Table = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Gestor CountryLanguage ");

        Toolbar.setRollover(true);

        NewButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/add_user.png"))); // NOI18N
        NewButton.setText("Nuevo");
        NewButton.setBorderPainted(false);
        NewButton.setContentAreaFilled(false);
        NewButton.setFocusable(false);
        NewButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        NewButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        NewButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NewButtonActionPerformed(evt);
            }
        });
        Toolbar.add(NewButton);
        Toolbar.add(Separator);

        EditButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/agt_family.png"))); // NOI18N
        EditButton.setText("Editar");
        EditButton.setBorderPainted(false);
        EditButton.setContentAreaFilled(false);
        EditButton.setEnabled(false);
        EditButton.setFocusable(false);
        EditButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EditButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        EditButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditButtonActionPerformed(evt);
            }
        });
        Toolbar.add(EditButton);

        DeleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/revert.png"))); // NOI18N
        DeleteButton.setText("Borrar");
        DeleteButton.setBorderPainted(false);
        DeleteButton.setContentAreaFilled(false);
        DeleteButton.setEnabled(false);
        DeleteButton.setFocusable(false);
        DeleteButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        DeleteButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Toolbar.add(DeleteButton);
        Toolbar.add(Separator2);

        SaveButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/save_all.png"))); // NOI18N
        SaveButton.setText("Guardar");
        SaveButton.setBorderPainted(false);
        SaveButton.setContentAreaFilled(false);
        SaveButton.setEnabled(false);
        SaveButton.setFocusable(false);
        SaveButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        SaveButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Toolbar.add(SaveButton);

        CancelButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/button_cancel.png"))); // NOI18N
        CancelButton.setText("Cancelar");
        CancelButton.setBorderPainted(false);
        CancelButton.setContentAreaFilled(false);
        CancelButton.setEnabled(false);
        CancelButton.setFocusable(false);
        CancelButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        CancelButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Toolbar.add(CancelButton);

        getContentPane().add(Toolbar, java.awt.BorderLayout.PAGE_START);

        Progress.setFont(Progress.getFont().deriveFont(Progress.getFont().getSize()-2f));
        Progress.setText("To Change");
        Progress.setBorder(javax.swing.BorderFactory.createEmptyBorder(3, 3, 3, 3));
        getContentPane().add(Progress, java.awt.BorderLayout.PAGE_END);

        Panel.setLayout(new java.awt.BorderLayout());

        Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        ScrollPaneTable.setViewportView(Table);

        Panel.add(ScrollPaneTable, java.awt.BorderLayout.CENTER);

        getContentPane().add(Panel, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NewButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NewButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NewButtonActionPerformed

    private void EditButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EditButtonActionPerformed

    public static void main(String args[]) {
      java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ListcountrylanguageFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CancelButton;
    private javax.swing.JButton DeleteButton;
    private javax.swing.JButton EditButton;
    private javax.swing.JButton NewButton;
    private javax.swing.JPanel Panel;
    private javax.swing.JLabel Progress;
    private javax.swing.JButton SaveButton;
    private javax.swing.JScrollPane ScrollPaneTable;
    private javax.swing.JToolBar.Separator Separator;
    private javax.swing.JToolBar.Separator Separator2;
    private javax.swing.JTable Table;
    private javax.swing.JToolBar Toolbar;
    // End of variables declaration//GEN-END:variables
}
