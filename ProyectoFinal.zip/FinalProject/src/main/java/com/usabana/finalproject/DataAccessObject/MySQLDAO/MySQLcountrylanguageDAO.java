package com.usabana.finalproject.DataAccessObject.MySQLDAO;

import com.usabana.finalproject.DataAccessObject.DAOException;
import com.usabana.finalproject.DataAccessObject.DBDAO.countrylanguageDAO;
import com.usabana.finalproject.DatabaseModel.countrylanguage;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MySQLcountrylanguageDAO implements countrylanguageDAO {

    private Connection Connect;

    final String INSERT = "INSERT INTO countrylanguage(CountryCode, Language, IsOfficial, Percentage) VALUES(?, ?, ?, ?)";
    final String UPDATE = "UPDATE countrylanguage SET CountryCode = ?, Language = ?, IsOfficial = ?, Percentage = ? WHERE Language = ? and CountryCode = ?";
    final String DELETE = "DELETE FROM countrylanguage WHERE Language = ? and CountryCode = ?";
    final String GETALL= "SELECT CountryCode, Language, IsOfficial, Percentage from countrylanguage";
    final String GET = "SELECT CountryCode, Language, IsOfficial, Percentage from countrylanguage WHERE Language = ? and CountryCode = ?";

    public MySQLcountrylanguageDAO(Connection Connect){
        this.Connect = Connect;
    }

    public void Insert(countrylanguage var) throws DAOException{

        PreparedStatement Stat = null;

        try {
            Stat = Connect.prepareStatement(INSERT);

            Stat.setString(1, var.getCountryCode());
            Stat.setString(2, var.getLanguage());
            Stat.setString(3, var.getIsOfficial());
            Stat.setFloat(4, var.getPercentage());

            Stat.executeUpdate();

            if (Stat.executeUpdate()==0){
                throw new DAOException("Puede que no se haya guardado");
            }
        }
        catch (SQLException exception) {
            throw new DAOException("Error en SQL", exception);
        }
        finally {
            if(Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException exception){
                    throw new DAOException("Error en SQL", exception);
                }
            }
        }
    }

    public void Modify(countrylanguage var) throws DAOException{

        PreparedStatement Stat = null;

        try {
            Stat = Connect.prepareStatement(UPDATE);

            Stat.setString(1, var.getCountryCode());
            Stat.setString(2, var.getLanguage());
            Stat.setString(3, var.getIsOfficial());
            Stat.setFloat(4, var.getPercentage());
            Stat.setString(5, var.getLanguage());
            Stat.setString(6, var.getCountryCode());

            Stat.executeUpdate();

            if (Stat.executeUpdate()==0){
                throw new DAOException("Puede que no se haya guardado");
            }
        }
        catch (SQLException exception) {
            throw new DAOException("Error en SQL", exception);
        }
        finally {
            if(Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException exception){
                    throw new DAOException("Error en SQL", exception);
                }
            }
        }
    }

    public void Delete(countrylanguage var) throws DAOException{

        PreparedStatement Stat = null;

        try {
            Stat = Connect.prepareStatement(DELETE);

            Stat.setString(1, var.getLanguage());
            Stat.setString(2, var.getCountryCode());

            Stat.executeUpdate();

            if (Stat.executeUpdate()==0){
                throw new DAOException("Puede que no se haya guardado");
            }
        }
        catch (SQLException exception) {
            throw new DAOException("Error en SQL", exception);
        }
        finally {
            if(Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException exception){
                    throw new DAOException("Error en SQL", exception);
                }
            }
        }
    }

    public List<countrylanguage> GetAll() throws DAOException{

        PreparedStatement Stat = null;
        ResultSet RS = null;
        List<countrylanguage> list = new ArrayList<>();

        try {
            Stat = Connect.prepareStatement(GETALL);

            RS = Stat.executeQuery();

            while (RS.next()){
                list.add(Convert(RS));
            }
        }
        catch (SQLException exception){
            throw new DAOException("Error en SQL.", exception);
        }
        finally {
            if (RS != null){
                try {
                    RS.close();
                }
                catch (SQLException exception){
                    new DAOException("Error en SQL", exception);
                }
            }
            if (Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException exception){
                    new DAOException("Error en SQL", exception);
                }
            }
        }
        return list;
    }

    public countrylanguage Get(String Language, String CountryCode) throws DAOException{

        PreparedStatement Stat = null;
        ResultSet RS = null;
        countrylanguage field = null;

        try {
            Stat = Connect.prepareStatement(GET);

            Stat.setString(1, Language);
            Stat.setString(2, CountryCode);

            RS = Stat.executeQuery();

            if (RS.next()){
                field = Convert(RS);
            } else{
                throw new DAOException("No se ha encontrado ese registro.");
            }
        }
        catch (SQLException exception){
            throw new DAOException("Error en SQL.", exception);
        }
        finally {
            if (RS != null){
                try {
                    RS.close();
                }
                catch (SQLException exception){
                    new DAOException("Error en SQL", exception);
                }
            }
            if (Stat != null){
                try {
                    Stat.close();
                }
                catch (SQLException exception){
                    new DAOException("Error en SQL", exception);
                }
            }
        }
        return field;
    }

    private countrylanguage Convert(ResultSet RS) throws SQLException{

        String CountryCode = RS.getString("CountryCode");
        String Language = RS.getString("Language");
        String IsOfficial = RS.getString("IsOfficial");
        float Percentage = RS.getFloat("Percentage");

        countrylanguage CountryLanguage = new countrylanguage(CountryCode, Language, IsOfficial, Percentage);

        return CountryLanguage;
    }
}