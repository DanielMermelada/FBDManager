package com.usabana.finalproject.Frames.city;

import com.usabana.finalproject.DataAccessObject.DAOException;
import com.usabana.finalproject.DataAccessObject.DBDAO.cityDAO;
import com.usabana.finalproject.DatabaseModel.city;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class cityTableModel extends AbstractTableModel{
    
    private cityDAO City;
    
    private List<city> Data = new ArrayList<>();
    
    public cityTableModel(cityDAO City){
        this.City = City;
    }
    
    public void UpdateModel() throws DAOException {
        Data = City.GetAll();
    }
    
    public String getColumnName(int column) {
        switch(column){
            case 0: return "ID";
            case 1: return "Name";
            case 2: return "CountryCode";
            case 3: return "District";
            case 4: return "Population";
            default: return null;
        }
    }

    public int getRowCount() {
        return Data.size();
    }

    public int getColumnCount() {
        return 5;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        city Instance = Data.get(rowIndex);
        switch(columnIndex){
            case 0: return Instance.getID();
            case 1: return Instance.getName();
            case 2: return Instance.getCountryCode();
            case 3: return Instance.getDistrict();
            case 4: return Instance.getPopulation();
            default: return null;
        }
    }
}
