package com.usabana.finalproject.DatabaseModel;

public class countrylanguage {
    private String CountryCode;
    private String Language;
    private String IsOfficial;
    private float Percentage;

    public countrylanguage(String countryCode, String language, String isOfficial, float percentage) {
        this.CountryCode = countryCode;
        this.Language = language;
        this.IsOfficial = isOfficial;
        this.Percentage = percentage;
    }

    public String getCountryCode() {
        return CountryCode;
    }

    public void setCountryCode(String countryCode) {
        this.CountryCode = countryCode;
    }

    public String getLanguage() {
        return Language;
    }

    public void setLanguage(String language) {
        this.Language = language;
    }

    public String getIsOfficial() {
        return IsOfficial;
    }

    public void setIsOfficial(String isOfficial) {
        this.IsOfficial = isOfficial;
    }

    public float getPercentage() {
        return Percentage;
    }

    public void setPercentage(float percentage) {
        this.Percentage = percentage;
    }

    public String toString() {
        return "countrylanguage{" +
                "CountryCode='" + CountryCode + '\'' +
                ", Language='" + Language + '\'' +
                ", IsOfficial='" + IsOfficial + '\'' +
                ", Percentage=" + Percentage +
                '}';
    }
}
